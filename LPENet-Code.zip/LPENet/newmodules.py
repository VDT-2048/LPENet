import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import copy
import os
from model.Network.utils.tensor_ops import cus_sample

def weight_init(module):
    for n, m in module.named_children():
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, (nn.BatchNorm2d, nn.InstanceNorm2d, nn.LayerNorm)):
            nn.init.ones_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Sequential):
            weight_init(m)
        elif isinstance(m, (
                nn.ReLU, nn.Sigmoid, nn.Softmax, nn.PReLU, nn.AdaptiveAvgPool2d, nn.AdaptiveMaxPool2d,
                nn.AdaptiveAvgPool1d,
                nn.Sigmoid, nn.Identity)):
            pass
        else:
            m.initialize()


class ConvBR(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, dilation=1, stride=1, padding=0):
        super(ConvBR, self).__init__()
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, dilation=dilation, stride=stride,
                              padding=padding, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        x = self.relu(x)
        return x


class convbnrelu(nn.Module):
    def __init__(self, in_channel, out_channel, k=3, s=1, p=1, g=1, d=1, bias=False, bn=True, relu=True):
        super(convbnrelu, self).__init__()
        conv = [nn.Conv2d(in_channel, out_channel, k, s, p, dilation=d, groups=g, bias=bias)]
        if bn:
            conv.append(nn.BatchNorm2d(out_channel))
        if relu:
            conv.append(nn.ReLU(inplace=True))
        self.conv = nn.Sequential(*conv)

    def forward(self, x):
        return self.conv(x)


class DSConv3x3(nn.Module):
    def __init__(self, in_channel, out_channel, stride=1, dilation=1, relu=True):
        super(DSConv3x3, self).__init__()
        self.conv = nn.Sequential(
            convbnrelu(in_channel, in_channel, k=3, s=stride, p=dilation, d=dilation, g=in_channel),
            convbnrelu(in_channel, out_channel, k=1, s=1, p=0, relu=relu)
        )

    def forward(self, x):
        return self.conv(x)


######################MCE######################
class CSR(nn.Module):
    def __init__(self, in_channels, out_channels=64):
        super(CSR, self).__init__()
        self.stage12 = DSConv3x3(in_channels, in_channels, stride=1, dilation=2)
        self.fuse1 = convbnrelu(in_channels, in_channels, k=1, s=1, p=0, relu=True)

        self.stage22 = DSConv3x3(in_channels, in_channels, stride=1, dilation=4)
        self.fuse2 = convbnrelu(in_channels, out_channels, k=1, s=1, p=0, relu=True)

    def forward(self, x):
        x12 = self.stage12(x)
        x1 = self.fuse1(x + x12)

        x22 = self.stage22(x1)
        x2 = self.fuse2(x + x1 + x22)

        return x2

class CSP(nn.Module):
    def __init__(self, in_channels, out_channels=64):
        super(CSP, self).__init__()
        self.conv1 = DSConv3x3(in_channels, in_channels, stride=1, dilation=1)
        self.conv2 = DSConv3x3(in_channels, in_channels, stride=1, dilation=2)
        self.conv3 = DSConv3x3(in_channels, in_channels, stride=1, dilation=3)
        self.fuse = DSConv3x3(in_channels, in_channels, stride=1, dilation=1)
        self.conv_out = DSConv3x3(in_channels, out_channels, stride=1, dilation=1)

    def forward(self, x):
        out1 = self.conv1(x)
        out2 = self.conv2(x + out1)
        out3 = self.conv3(x + out2 + out1)
        out_s = self.fuse(out3 + out2 + out1)
        out_mp = self.conv_out(x + out_s)
        return out_mp


class MCE(nn.Module):
    def __init__(self, in_channels, out_channels=64):
        super(MCE, self).__init__()
        self.conv_a = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=True)
        self.CSP = CSP(in_channels, out_channels)
        self.CSR = CSR(in_channels, out_channels)

    def forward(self, x):
        x1 = self.conv_a(x)
        x2 = self.CSP(x)
        x3 = self.CSR(x)

        out = x1 + x2 + x3

        return out


####################################PGF#########################################
##################GCB####################
class GlobalContextBlock(nn.Module):
    def __init__(self, inplanes, ratio, pooling_type='att', fusion_types=('channel_add',)):
        super(GlobalContextBlock, self).__init__()
        assert pooling_type in ['avg', 'att']
        assert isinstance(fusion_types, (list, tuple))
        valid_fusion_types = ['channel_add', 'channel_mul']
        assert all([f in valid_fusion_types for f in fusion_types])
        assert len(fusion_types) > 0, 'at least one fusion should be used'
        self.inplanes = inplanes
        self.ratio = ratio
        self.planes = int(inplanes * ratio)
        self.pooling_type = pooling_type
        self.fusion_types = fusion_types
        if pooling_type == 'att':
            self.conv_mask = nn.Conv2d(inplanes, 1, kernel_size=1)
            self.softmax = nn.Softmax(dim=2)
        else:
            self.avg_pool = self.avg_pool = nn.AdaptiveAvgPool2d(1)
        if 'channel_add' in fusion_types:
            self.channel_add_conv = nn.Sequential(
                nn.Conv2d(self.inplanes, self.planes, kernel_size=1),
                nn.LayerNorm([self.planes, 1, 1]),
                nn.ReLU(inplace=True),  # yapf: disable
                nn.Conv2d(self.planes, self.inplanes, kernel_size=1))
        else:
            self.channel_add_conv = None
        if 'channel_mul' in fusion_types:
            self.channel_mul_conv = nn.Sequential(
                nn.Conv2d(self.inplanes, self.planes, kernel_size=1),
                nn.LayerNorm([self.planes, 1, 1]),
                nn.ReLU(inplace=True),  # yapf: disable
                nn.Conv2d(self.planes, self.inplanes, kernel_size=1))
        else:
            self.channel_mul_conv = None

    def spatial_pool(self, x):
        batch, channel, height, width = x.size()
        if self.pooling_type == 'att':
            input_x = x
            # [N, C, H * W]
            input_x = input_x.view(batch, channel, height * width)
            # [N, 1, C, H * W]
            input_x = input_x.unsqueeze(1)
            # [N, 1, H, W]
            context_mask = self.conv_mask(x)
            # [N, 1, H * W]
            context_mask = context_mask.view(batch, 1, height * width)
            # [N, 1, H * W]
            context_mask = self.softmax(context_mask)
            # [N, 1, H * W, 1]
            context_mask = context_mask.unsqueeze(-1)
            # [N, 1, C, 1]
            context = torch.matmul(input_x, context_mask)
            # [N, C, 1, 1]
            context = context.view(batch, channel, 1, 1)
        else:
            # [N, C, 1, 1]
            context = self.avg_pool(x)

        return context

    def forward(self, x):
        # [N, C, 1, 1]
        context = self.spatial_pool(x)
        out = x
        if self.channel_mul_conv is not None:
            # [N, C, 1, 1]
            channel_mul_term = torch.sigmoid(self.channel_mul_conv(context))
            out = out * channel_mul_term
        if self.channel_add_conv is not None:
            # [N, C, 1, 1]
            channel_add_term = self.channel_add_conv(context)
            out = out + channel_add_term

        return out


class PGF(nn.Module):
    def __init__(self, num_channels=64):
        super(PGF, self).__init__()

        self.conv_cross1 = nn.Conv2d(3 * num_channels, num_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.conv_cross2 = nn.Conv2d(2 * num_channels, num_channels, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn_cross = nn.BatchNorm2d(num_channels)
        self.Global = GlobalContextBlock(64, 0.25)
        self.gap = nn.AdaptiveAvgPool2d((1, 1))
        self.convg = nn.Conv2d(64, 64, 1)
        self.sftmax = nn.Softmax(dim=1)

    def forward(self, in1, in2, in3=None):

        if in3 is not None:
            in2 = F.interpolate(in2, size=in1.size()[2:], mode='bilinear')
            in3 = F.interpolate(in3, size=in1.size()[2:], mode='bilinear')
            in3_c = self.convg(self.gap(in3))
            in22 = torch.mul(self.sftmax(in3_c) * in3_c.shape[1], in2)
            in33 = in3 * F.sigmoid(in2)
            x = torch.cat((in1, in22, in33), 1)
            x = F.relu(self.bn_cross(self.conv_cross1(x)))
        else:
            if in1.size()[2] > in2.size()[2]:
                in2 = F.interpolate(in2, size=in1.size()[2:], mode='bilinear')
                in1_c = self.convg(self.gap(in1))
                in11 = torch.mul(self.sftmax(in1_c) * in1_c.shape[1], in2)
                in22 = in1 * F.sigmoid(in2)
                x = torch.cat((in11, in22), 1)
            else:
                in2 = F.interpolate(in2, size=in1.size()[2:], mode='bilinear')
                in2_c = self.convg(self.gap(in2))
                in22 = torch.mul(self.sftmax(in2_c) * in2_c.shape[1], in1)
                in11 = in2 * F.sigmoid(in1)
                x = torch.cat((in11, in22), 1)
            x = F.relu(self.bn_cross(self.conv_cross2(x)))

        context = self.Global(x)
        out = x * context
        out = out + x

        return out


####################################BEA#########################################
class EE(nn.Module):
    def __init__(self, in_dim, norm, act):
        super().__init__()
        self.out_conv = nn.Sequential(
            nn.Conv2d(in_dim, in_dim, 1, bias=False),
            norm(in_dim),
            nn.Sigmoid()
        )
        self.pool = nn.AvgPool2d(3, stride=1, padding=1)

    def forward(self, x):
        edge = self.pool(x)
        edge = x - edge
        edge = self.out_conv(edge)
        edge = edge * x
        return x + edge


class ME(nn.Module):
    def __init__(self, in_dim, hidden_dim, width, norm, act):
        super().__init__()
        self.in_dim = in_dim
        self.hidden_dim = hidden_dim
        self.width = width
        self.in_conv = nn.Sequential(
            nn.Conv2d(in_dim, hidden_dim, 1, bias=False),
            norm(hidden_dim),
            nn.Sigmoid()
        )

        self.pool = nn.AvgPool2d(3, stride=1, padding=1)

        self.mid_conv = nn.ModuleList()
        self.edge_enhance = nn.ModuleList()
        for i in range(width - 1):
            self.mid_conv.append(nn.Sequential(
                nn.Conv2d(hidden_dim, hidden_dim, 1, bias=False),
                norm(hidden_dim),
                nn.Sigmoid()
            ))
            self.edge_enhance.append(EE(hidden_dim, norm, act))

        self.out_conv = nn.Sequential(
            nn.Conv2d(hidden_dim * width, in_dim, 1, bias=False),
            norm(in_dim),
            act()
        )

    def forward(self, x):
        mid = self.in_conv(x)
        out = mid
        for i in range(self.width - 1):
            mid = self.pool(mid)
            mid = self.mid_conv[i](mid)
            out = torch.cat([out, self.edge_enhance[i](mid)], dim=1)
        out = self.out_conv(out)
        return out

class BEA(nn.Module):
    def __init__(self, in_dim, hidden_dim, width, norm, act):
        super().__init__()
        self.img_in_conv = nn.Sequential(
            nn.Conv2d(3, 64, 3, padding=1, bias=False),
            norm(64),
            act()
        )
        self.me = ME(64, 64, 4, norm, act)

    def forward(self, x):
        m1 = self.img_in_conv(x)
        m2 = self.me(m1)

        return m2


class OutConv1(nn.Module):
    def __init__(self, in_channels):
        super(OutConv1, self).__init__()
        self.conv1 = nn.Conv2d(96, 64, kernel_size=1)

    def forward(self, x):
        return self.conv1(x)


class OutConv(nn.Module):
    def __init__(self, in_channels):
        super(OutConv, self).__init__()
        self.conv = nn.Conv2d(64, 64, kernel_size=1)

    def forward(self, x):
        return self.conv(x)

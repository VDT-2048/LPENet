#!/usr/bin/python3
# coding=utf-8

import torch
from fvcore.nn import FlopCountAnalysis, parameter_count_table
from model.get_model import get_model

class Config:
    def __init__(self, datapath, snapshot, mode):
        self.datapath = datapath
        self.snapshot = snapshot
        self.mode = mode

def get_cfg():
    eval_path = '/home/abc-123/桌面/SRPCMAIN/SSP2000/Test'
    weights_path = '/home/abc-123/桌面/SRPCMAIN/main/checkpoint/SRPC10'  # Replace with actual checkpoint
    return Config(datapath=eval_path, snapshot=weights_path, mode='eval')

def compute_model_complexity(model, input_size=(1, 3, 224, 224)):
    model.eval()

    # Compute parameter count
    param_count = sum(p.numel() for p in model.parameters()) / 1e6  # In Million

    # Compute FLOPs
    dummy_input = torch.randn(input_size).cuda()
    flops = FlopCountAnalysis(model, dummy_input)
    total_flops = flops.total() / 1e9  # Convert to GFLOPs

    print(f"Model has {param_count:.4f}M parameters and {total_flops:.4f} GFLOPs.")

    return param_count, total_flops

if __name__ == "__main__":
    cfg = get_cfg()
    model = get_model(cfg, 'SRPC')
    compute_model_complexity(model)

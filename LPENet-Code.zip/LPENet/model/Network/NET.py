import torch
import torch.nn as nn
import torch.nn.functional as F
from encoder import PFE
from newmodules import MCE, PGF, BEA, OutConv1, OutConv
from .utils.tensor_ops import cus_sample, upsample_add
from fvcore.nn import FlopCountAnalysis, parameter_count

def weight_init(module):
    for n, m in module.named_children():
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, (nn.BatchNorm2d, nn.InstanceNorm2d)):
            nn.init.ones_(m.weight)
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.kaiming_normal_(m.weight, mode='fan_in', nonlinearity='relu')
            if m.bias is not None:
                nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Sequential):
            weight_init(m)
        elif isinstance(m, (nn.ReLU, nn.Sigmoid, nn.PReLU, nn.AdaptiveAvgPool2d, nn.AdaptiveAvgPool1d, nn.Identity)):
            pass

class LPENet(torch.nn.Module):
    def __init__(self, cfg, model_name='LPENet'):
        super(LPENet, self).__init__()
        self.cfg = cfg
        self.model_name = model_name
        if self.model_name == "LPENet":
            self.encoder = PFE()

        else:
            print("UNDEFINED BACKBONE NAME.")

        self.mce1 = MCE(96, 64)
        self.mce2 = MCE(96, 64)
        self.mce3 = MCE(96, 64)
        self.mce4 = MCE(96, 64)

        self.pgf1 = PGF()
        self.pgf2 = PGF()
        self.pgf3 = PGF()
        self.pgf4 = PGF()

        self.bea = BEA(in_dim=3, hidden_dim=64, width=4, norm=nn.BatchNorm2d, act=nn.Sigmoid)

        self.outconv1 = OutConv1(96)
        self.outconv = OutConv(64)

        self.predtrans1 = nn.Conv2d(64, 1, kernel_size=3, padding=1)
        self.predtrans2 = nn.Conv2d(64, 1, kernel_size=3, padding=1)
        self.predtrans3 = nn.Conv2d(64, 1, kernel_size=3, padding=1)
        self.predtrans4 = nn.Conv2d(64, 1, kernel_size=3, padding=1)

        self.initialize()

    def forward(self, x, shape=None):
        x0_1, x0_2, x0_3, x0_4 = self.encoder(x)


        x1 = self.mce1(x0_1)
        x2 = self.mce2(x0_2)
        x3 = self.mce3(x0_3)
        x4 = self.mce4(x0_4)

        x44 = self.pgf4(in1=x4, in2=x3)
        x33 = self.pgf3(in1=x3, in2=x2, in3=x44)
        x22 = self.pgf2(in1=x2, in2=x1, in3=x33)
        x11 = self.pgf1(in1=x1, in2=x22)

        x_m = self.bea(x)
        xx = self.outconv1(x0_1)
        xx = F.interpolate(xx, size=x_m.shape[2:], mode='bilinear')
        xxx = F.interpolate(x1, size=x_m.shape[2:], mode='bilinear')
        x11_1 = F.interpolate(x11, size=x_m.shape[2:], mode='bilinear')
        x111 = x_m + xxx + xx + x11_1

        x_out = self.outconv(x111)


        if shape is None:
            shape = x.size()[2:]

        pred1 = F.interpolate(self.predtrans1(x_out), size=shape, mode='bilinear')
        pred2 = F.interpolate(self.predtrans2(x22), size=shape, mode='bilinear')
        pred3 = F.interpolate(self.predtrans3(x33), size=shape, mode='bilinear')
        pred4 = F.interpolate(self.predtrans4(x44), size=shape, mode='bilinear')

        return pred1, pred2, pred3, pred4

    def initialize(self):
        if self.cfg.snapshot:
            self.load_state_dict(torch.load(self.cfg.snapshot))
        else:
            weight_init(self)

# 测试 FLOPs/Params
if __name__ == "__main__":
    class DummyCfg:
        snapshot = None

    dummy_cfg = DummyCfg()
    model = LPENet(cfg=dummy_cfg, model_name='SRPC')
    model.eval()

    dummy_input = torch.randn(1, 3, 352, 352)  # 模拟输入
    flops = FlopCountAnalysis(model, dummy_input)
    params = parameter_count(model)

    print(f"FLOPs: {flops.total() / 1e9:.2f} GFLOPs")
    print(f"Params: {params[''] / 1e6:.2f} M")


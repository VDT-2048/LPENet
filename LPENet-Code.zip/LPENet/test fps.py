import os
import time
import numpy as np
import torch
from tqdm import tqdm
from PIL import Image
from torchvision import transforms

from model.Network.NET import LPENet

class DummyCfg:
    def __init__(self):
        self.snapshot = None
def preload_images(image_dir, device='cuda', target_size=(), max_images=None, use_fp16=False):
    transform = transforms.Compose([
        transforms.Resize(target_size),
        transforms.ToTensor()
    ])
    image_list = sorted([
        os.path.join(image_dir, f)
        for f in os.listdir(image_dir)
        if f.lower().endswith(('.jpg', '.png', '.jpeg'))
    ])
    if max_images:
        image_list = image_list[:max_images]

    tensors = []
    for path in tqdm(image_list, desc="Loading images"):
        img = Image.open(path).convert('RGB')
        tensor = transform(img).unsqueeze(0)  # [1, 3, H, W]
        if use_fp16:
            tensor = tensor.half()
        tensors.append(tensor.to(device))
    return tensors

# 3. 性能测试核心函数
def computeTime(model, image_tensors, batch_size=1, device='cuda', warmup_batches=2):
    total_batches = len(image_tensors) // batch_size
    infer_times, read_times, save_times, total_times = [], [], [], []

    for i in tqdm(range(total_batches), desc="Benchmarking"):
        t0 = time.time()
        start_read = time.time()
        batch = image_tensors[i * batch_size: (i + 1) * batch_size]
        inputs = torch.cat(batch, dim=0)
        if use_channels_last:
            inputs = inputs.contiguous(memory_format=torch.channels_last)
        end_read = time.time()

        # 推理阶段
        start_infer = time.time()
        with torch.no_grad():
            output = model(inputs)
        torch.cuda.synchronize()
        end_infer = time.time()

        # 模拟保存
        start_save = time.time()
        _ = output[0].detach().cpu().numpy()
        end_save = time.time()
        t1 = time.time()

        if i >= warmup_batches:
            read_times.append(end_read - start_read)
            infer_times.append(end_infer - start_infer)
            save_times.append(end_save - start_save)
            total_times.append(t1 - t0)

    print("\n====== Performance Report ======")
    print(f"Batch Size: {batch_size} | Total: {len(read_times) * batch_size}")
    print(f"Inference  | Time/image: {np.mean(infer_times)/batch_size:.4f}s  FPS: {batch_size / np.mean(infer_times):.2f}")
    print(f"Read       | Time/image: {np.mean(read_times)/batch_size:.4f}s  FPS: {batch_size / np.mean(read_times):.2f}")
    print(f"Save       | Time/image: {np.mean(save_times)/batch_size:.4f}s  FPS: {batch_size / np.mean(save_times):.2f}")
    print(f"Total Flow | Time/image: {np.mean(total_times)/batch_size:.4f}s  FPS: {batch_size / np.mean(total_times):.2f}")
    print("================================")

if __name__ == '__main__':
    torch.backends.cudnn.benchmark = True

    use_fp16 = True
    use_channels_last = True
    use_torch_compile = True
    batch_size = 1
    device = 'cuda'

    # 加载模型
    cfg = DummyCfg()
    model = LPENet(cfg)
    checkpoint = torch.load('./')
    model.load_state_dict(checkpoint)

    model = model.eval().to(device)
    if use_channels_last:
        model = model.to(memory_format=torch.channels_last)
    if use_fp16:
        model = model.half()
    if use_torch_compile:
        model = torch.compile(model)

    # 加载图像
    image_folder = ''
    image_tensors = preload_images(
        image_folder,
        device=device,
        max_images=600,
        use_fp16=use_fp16
    )

    computeTime(model, image_tensors, batch_size=batch_size, device=device)





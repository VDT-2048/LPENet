import torch
import torch.nn as nn

class PFEB(nn.Module):
    def __init__(self, dim, act=nn.ReLU):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.f = nn.Linear(dim, 6 * dim)
        self.act = act()
        self.g = nn.Linear (3 * dim, dim)

    def forward(self, x):
        B, C, H, W = x.shape
        x = x.permute(0, 2, 3, 1).reshape(B * H * W, C)

        input_mlp = x
        x = self.norm(x)
        x = self.f(x)
        x1, x2 = x.reshape(-1, 2, 3 * C).unbind(1)
        x = self.act(x1) * x2
        x = self.g(x)
        x = input_mlp + x

        x = x.reshape(B, H, W, C).permute(0, 3, 1, 2)
        return x


class PFE(nn.Module):
    def __init__(self, in_chans=3, dim=96, depth=4):
        super().__init__()
        # CNN stem
        self.stem = nn.Sequential(
            nn.Conv2d(in_chans, dim // 4, 3, stride=2, padding=1),
            nn.BatchNorm2d(dim // 4),
            nn.ReLU6(),
            nn.Conv2d(dim // 4, dim // 2, 3, stride=2, padding=1),
            nn.BatchNorm2d(dim // 2),
            nn.ReLU6(),
            nn.Conv2d(dim // 2, dim, 3, stride=1, padding=1),
            nn.BatchNorm2d(dim),
            nn.ReLU6()
        )

        # 特征提取块
        self.blocks = nn.Sequential(*[
            PFEB(dim=dim, act=nn.ReLU)
            for _ in range(depth)
        ])

    def forward(self, x):
        features = []
        x = self.stem(x)
        for _ in range(4):
            x = self.blocks(x)
            features.append(x)
        return features






